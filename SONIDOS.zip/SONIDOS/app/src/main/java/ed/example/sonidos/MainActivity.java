package ed.example.sonidos;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onDestroy() {
        super.onDestroy();
        spool.release();
        spool=null;
        player.release();
        player=null;

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        textView1=findViewById(R.id.textView);
        textView2=findViewById(R.id.textView2);


if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
    AudioAttributes attributes =new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
    spool =new SoundPool.Builder()
            .setAudioAttributes(attributes)
            .setMaxStreams(10).build();
}
else{
    spool =new SoundPool(6,audioManager.STREAM_MUSIC,0);
}
        sound1=spool.load(this,R.raw.gallina,1);
        sound2=spool.load(this,R.raw.perro,1);
        sound3=spool.load(this,R.raw.leon,1);
        sound4=spool.load(this,R.raw.serpiente,1);
        audioManager=(AudioManager) getSystemService(AUDIO_SERVICE);
        volumen=findViewById(R.id.seekBar);
        volumen.setMax(audioManager.getStreamMaxVolume(audioManager.STREAM_MUSIC));
        volumen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,i,0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



    }






    public void suenaboton1(View V){
        spool.play(sound1,1,1,1,0,1);
    }
    public void suenaboton2(View V){
        spool.play(sound2,1,1,1,2,1);
    }
    public void suenabotonLEON(View V){
        spool.play(sound3,1,1,1,0,1);
    }
    public void suenabotonSNAKE(View V){
        spool.play(sound4,1,1,1,2,1);
    }
    public void suenaboton3(View V) {
        if (player != null && player.isPlaying()) {
            player.stop();
            button3.setText("REPRODUCIR MEDIA PLAYER");
        } else {
            player = MediaPlayer.create(this, R.raw.pharrell_williams_happy);
            textView1.setText("SONANDO " + String.valueOf(player.getDuration()));
            player.start();
            button3.setText("DETENER");
        }
    }

        public void suenaboton4(View V){
            if (player != null) {
                if (player.isPlaying()) {
                    player.pause();
                    ;
                    textView2.setText("DETENIDO  " + String.valueOf(player.getCurrentPosition()));
                    button4.setText("REINICIAR");
                } else {
                    player.start();
                    button4.setText("PAUSAR");
                }
            }

    }





    private SoundPool spool;
private MediaPlayer player;
private AudioManager audioManager;
private int sound1, sound2,sound3,sound4;
private Button button3,button4;
private SeekBar volumen;
private TextView textView1, textView2;




}